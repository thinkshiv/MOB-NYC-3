//
//  ViewController.swift
//  TableCells
//
//  Created by William Martin on 6/25/15.
//  Copyright (c) 2015 Anomalus. All rights reserved.
//

import UIKit


extension UIView {
    class func loadFromNibNamed(nibNamed: String, bundle : NSBundle? = nil) -> UIView? {
        return UINib(
            nibName: nibNamed,
            bundle: bundle
            ).instantiateWithOwner(nil, options: nil)[0] as? UIView
    }
}


class Message {
    var title: String
    var body: String
    
    init(title:String, body:String) {
        self.title = title
        self.body = body
    }
    
}


class MessageCell: UITableViewCell {
    var message: Message!
    
    @IBOutlet var titleLabel : UILabel!
    @IBOutlet var bodyText : UITextView!
    
    func populate() {
        println(self.titleLabel)
        
        if let _titleLabel = self.titleLabel {
            _titleLabel.text = self.message.title
        }
        
        if let _bodyText = self.bodyText {
            _bodyText.text = self.message.body
        }
    }
    
//    override func layoutSubviews() {
//        super.layoutSubviews()
//        
//        let centerY = self.frame.height / CGFloat(2.0)
//        let labelCenterY = self.label.frame.height / CGFloat(2.0)
//        let newLabelTop = centerY - labelCenterY
//        let newFrame = CGRectMake(4, newLabelTop, self.bounds.size.width, cellHeight)
//        
//        self.label.frame = newFrame
//    }
}


class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    var messages : [Message] = [
        Message(title: "Hello!", body: "Nice to see you"),
        Message(title: "What's up?", body: "Looking forward to it!")
    ]
    
    @IBOutlet var messageTable : UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.messageTable.registerNib(UINib(nibName: "MessageTableCell", bundle: nil), forCellReuseIdentifier: "MessageCell")
//        self.messageTable.registerClass(MessageCell.self, forCellReuseIdentifier: "MessageCell")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.messages.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("MessageCell", forIndexPath: indexPath) as! MessageCell
        
        println("cell for \(indexPath.row)")
        cell.message = self.messages[indexPath.row]
        cell.populate()
        
        return cell
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 250
    }
}

